# Expense-Tracker

The Expense Tracker is a simple web application that allows users to track their expenses and manage their financial activities easily. 
It provides a user-friendly interface for recording and categorizing expenses, generating reports, and monitoring spending habits.

Features

1. Expense Recording: Users can easily record their expenses by entering the expense amount, category, and date.
2. Expense Categories: Expenses can be categorized into predefined categories such as groceries, transportation,
   utilities, etc., or users can create their own custom categories.
3. Reports: The application provides various reports and visualizations to help users analyze their spending patterns, 
 including expense breakdown by category and monthly expense trends.
4. Budgeting: Users can set monthly budgets for different expense categories and receive alerts when they are close to exceeding the budget. 

Technologies Used
Frontend: HTML, CSS, JavaScript

Live Demo of Project :  https://wtfashwin.github.io/Expense-Tracker/
