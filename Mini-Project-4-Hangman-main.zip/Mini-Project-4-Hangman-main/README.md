The Hangman Game is a classic word-guessing game where players try to guess a hidden word by suggesting letters within a certain number of attempts. This project is a web-based implementation of the Hangman game, 
allowing players to play the game directly in their web browsers.



Features
1. Word Selection: The game randomly selects a word from a predefined word list, ensuring a different game experience each time.
2. Word Masking: The selected word is initially masked, displaying only the number of letters and placeholders for each letter.
3. Guessing Letters: Players can guess letters one by one to reveal any occurrences of the guessed letter in the word.
4. Game Status: The game keeps track of the player's attempts, remaining guesses, and the letters already guessed.
5. Win/Loss Conditions: The game determines whether the player wins by guessing the word correctly within the specified number of attempts or loses by running out of guesses.

Technologies Used
Frontend: HTML, CSS, JavaScript


LIVE DEMO OF PROJECT :  https://wtfashwin.github.io/Mini-Project-4-Hangman/
