const form = document.querySelector('#new-task-form');
const input = document.querySelector('#new-task');
const list = document.querySelector('#task-list');

form.addEventListener('submit', addTask);

function addTask(event) {
  event.preventDefault();

  if (!input.value.trim()) {
    return;
  }

  const task = createTaskElement(input.value);
  list.appendChild(task);

  input.value = '';
  input.focus();
}

function createTaskElement(taskText) {
  const task = document.createElement('li');
  const checkbox = createCheckbox();
  const label = createLabel(taskText);
  const deleteButton = createDeleteButton();

  task.appendChild(checkbox);
  task.appendChild(label);
  task.appendChild(deleteButton);

  return task;
}

function createCheckbox() {
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.addEventListener('change', toggleTaskStatus);
  return checkbox;
}

function toggleTaskStatus() {
  this.parentNode.classList.toggle('checked');
}

function createLabel(taskText) {
  const label = document.createElement('label');
  label.textContent = taskText;
  return label;
}

function createDeleteButton() {
  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', deleteTask);
  return deleteButton;
}

function deleteTask() {
  this.parentNode.remove();
}
