document.addEventListener("DOMContentLoaded", function () {
    // Function to fetch and display registered users
    function displayRegisteredUsers() {
      // Fetch data from the server or JSON file
      fetch('registered_users.json')
        .then(response => response.json())
        .then(data => {
          const userList = document.getElementById('userList');
  
          userList.innerHTML = '';
  
          const table = document.createElement('table');
          const tableHeader = document.createElement('thead');
          const tableBody = document.createElement('tbody');
  
          const headerRow = document.createElement('tr');
          headerRow.innerHTML = `<th>Username</th><th>First Name</th><th>Last Name</th>`;
          tableHeader.appendChild(headerRow);
          table.appendChild(tableHeader);
  
          data.registeredUsers.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
              <td>${user.username}</td>
              <td>${user.firstName}</td>
              <td>${user.lastName}</td>
            `;
            tableBody.appendChild(row);
          });
  
          table.appendChild(tableBody);
  
          userList.appendChild(table);
        })
        .catch(error => console.error('Error:', error));
    }
  
    displayRegisteredUsers();
  });
  