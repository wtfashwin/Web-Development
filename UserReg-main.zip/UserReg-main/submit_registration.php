{
    "registeredUsers": [
      {
        "username": "john_doe",
        "password": "hashed_password", 
        "firstName": "John",
        "lastName": "Doe",
        "dob": "1990-01-01",
        "location": "New York",
        "phone": "123-456-7890"
      }
    ]
  }
    